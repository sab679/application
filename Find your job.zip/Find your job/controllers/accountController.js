const bcrypt = require("bcrypt");
const Organization = require("../Models/Organization");
const Account = require("../Models/Account");
const jwt = require("jsonwebtoken");

// Register a new user or organization
const registerAccount = async (req, res) => {
  const { fullName, email, password, role } = req.body;
  try {
    const existingAccount = await Account.findOne({ where: { email } });
    if (existingAccount) {
      return res.status(400).json({ error: "Email already in use" });
    }

    const hashedPassword = await bcrypt.hash(password, 10);
    const account = await Account.create({ fullName, email, password: hashedPassword, role });
    const token = jwt.sign({ id: account.id, role: account.role }, process.env.JWT_SECRET, { expiresIn: "1h" });
    res.cookie("token", token, { httpOnly: true, secure: process.env.NODE_ENV === 'production' });

    res.redirect("/dashboard");
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

const loginAccount = async (req, res) => {  const { email, password } = req.body;

// Check if required fields are present
if (!email || !password) {
  return res.status(400).json({ error: "Email and password are required" });
}

try {
  const account = await Account.findOne({ where: { email } });
  if (!account) {
    return res.status(404).json({ error: "Account not found" });
  }

  const validPassword = await bcrypt.compare(password, account.password);
  if (!validPassword) {
    return res.status(400).json({ error: "Invalid password" });
  }

  // Generate JWT token
  const token = jwt.sign({ id: account.id, role: account.role }, process.env.JWT_SECRET, { expiresIn: "1h" });
  res.cookie("token", token, { httpOnly: true });
  res.redirect("/dashboard");
} catch (error) {
  res.status(500).json({ error: error.message });
}
 };
const logoutAccount = (req, res) => { 
  res.clearCookie("token");
  res.redirect("/");res.clearCookie("token");
  res.redirect("/"); };

module.exports = { registerAccount, loginAccount, logoutAccount };
