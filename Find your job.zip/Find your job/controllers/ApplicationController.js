const Application = require("../Models/Application"); // Formerly JobApplication
const Position = require("../Models/Position"); // Formerly Job

// Create a new application for a position
const createApplication = async (req, res) => {
  const positionId = req.params.id;

  try {
    // Create a new application
    const application = await Application.create({ accountId: req.user.id, positionId });

    // Fetch all applications by the current user
    let applications = await Application.findAll({ where: { accountId: req.user.id } });

    // Populate position details in each application
    applications = await Promise.all(
      applications.map(async (app) => {
        const position = await Position.findByPk(app.positionId);
        app.position = position;
        return app;
      })
    );

    // res.render("positions/applications", { applications, role: req.user.role });
    res.render("applications", { applications, role: req.user.role });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: error.message });
  }
};

// Get all applications by the logged-in user
const getApplications = async (req, res) => {
  try {
    let applications = await Application.findAll({ where: { accountId: req.user.id } });
    console.log("Applications:", applications); // Debugging applications before population

    // Populate position details in each application
    applications = await Promise.all(
      applications.map(async (app) => {
        const position = await Position.findByPk(app.positionId);
        console.log("Fetched position for application:", position); // Debugging positions
        app.position = position;
        return app;
      })
    );

    res.render("positions/applications", { applications, role: req.user.role });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: error.message });
  }
};

// Get applications for a specific position
const getApplicationsByPosition = async (req, res) => {
  try {
    const positionId = req.params.positionId;

    // Fetch all applications for the specified position
    let applications = await Application.findAll({ where: { positionId } });

    // Populate position details in each application
    applications = await Promise.all(
      applications.map(async (app) => {
        const position = await Position.findByPk(app.positionId);
        app.position = position;
        return app;
      })
    );

    res.render("positions/applications", { applications, role: req.user.role });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: error.message });
  }
};

module.exports = {
  createApplication,
  getApplications,
  getApplicationsByPosition,
};
