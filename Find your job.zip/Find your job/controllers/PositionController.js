const { where, Op } = require("sequelize");
const Position = require("../Models/Position"); // Formerly Job

// Create a new position
const createPosition = async (req, res) => {
  const { positionTitle, positionDetails, workLocation, compensation, employmentType, closesAt } = req.body;

  // Validate required fields
  if (!positionTitle || !positionDetails || !workLocation || !compensation || !employmentType || !closesAt) {
    return res
      .status(400)
      .json({ error: "positionTitle, positionDetails, workLocation, compensation, employmentType, and closesAt are required" });
  }

  try {
    const position = await Position.create({
      positionTitle,
      positionDetails,
      workLocation,
      compensation,
      employmentType,
      organizationId: req.user.id, // Assuming req.user.id refers to the employer's organization ID
      closesAt,
    });
    res.redirect("/positions/list");
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Get positions created by the logged-in employer
const getPositionsWithOrganization = async (req, res) => {
  try {
    const positions = await Position.findAll({
      where: {
        organizationId: req.user.id,
      },
    });
    res.render("positionLists", { positions, role: req.user.role });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Get all active positions
const getAllPositions = async (req, res) => {
  try {
    const positions = await Position.findAll({
      where: {
        closesAt: {
          [Op.gt]: new Date(),
        },
      },
    });
    res.render("positionLists", { positions, role: req.user.role });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Delete a position by ID
const deletePosition = async (req, res) => {
  const positionId = req.params.id;
  try {
    await Position.destroy({
      where: {
        id: positionId,
      },
    });
    res.redirect("positionLists");
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

module.exports = {
  createPosition,
  getPositionsWithOrganization,
  getAllPositions,
  deletePosition,
};
